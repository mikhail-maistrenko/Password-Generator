package com.example.passwordgenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.renderscript.ScriptGroup;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText login,password;
    Button btn,btnSave,btnLoad;
    SharedPreferences sp;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences("pwd",MODE_PRIVATE);
        login = findViewById(R.id.login);
        password = findViewById(R.id.password);
        btn = (Button) findViewById(R.id.btn_gen);
        btnSave = (Button) findViewById(R.id.btn_save);
        btnLoad = (Button) findViewById(R.id.btn_load);
        Button bt_copy = (Button) findViewById(R.id.bt_copy);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                password.setText(generateString(8));
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sp.edit();
                editor.putString(login.getText().toString(),password.getText().toString());
                editor.commit();
            }
        });

        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pass= sp.getString(login.getText().toString(),"not found");
                password.setText(pass);
            }
        });

        bt_copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Value = INPUT_SERVICE.toString();
                if (Value.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please insert data", Toast.LENGTH_SHORT).show();
                } else {
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("Data", LOCALE_SERVICE);
                    clipboardManager.setPrimaryClip(clipData);
                    Toast.makeText(getApplicationContext(), "Copied to Clipboard", Toast.LENGTH_SHORT).show();
                }
            }

        });


    }



    private String generateString(int length) {
        char[] chars = "QWERTYUIOPASDFGHJKLZXCVBNM0123456789qwertyuiopasdfghjklzxcvbnm!_".toCharArray();
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = chars[r.nextInt(chars.length)];
            StringBuilder append = sb.append(c);
        }
        return sb.toString();
    }
}
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        password = (TextView) findViewById(R.id.password);
//        btn = (Button) findViewById(R.id.btn);
//        Button bt_copy = (Button) findViewById(R.id.bt_copy);
//        //Button bt_clear=(Button)findViewById(R.id.bt_clear);
//
//        bt_copy.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String Value = INPUT_SERVICE.toString();
//                if (Value.isEmpty()) {
//                    Toast.makeText(getApplicationContext(), "Please insert data", Toast.LENGTH_SHORT).show();
//                } else {
//                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
//                    ClipData clipData = ClipData.newPlainText("Data", LOCALE_SERVICE);
//                    clipboardManager.setPrimaryClip(clipData);
//                    Toast.makeText(getApplicationContext(), "Copied to Clipboard", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//        });
////        bt_clear.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                String Text = INPUT_SERVICE.toString();
////                if(Text.isEmpty()){
////                    Toast.makeText(getApplicationContext(),"Alredy Empty",Toast.LENGTH_SHORT).show();
////                }
////                    else {
////                        INPUT_SERVICE("");
////                }
////            }
////
////            private void INPUT_SERVICE(String s) {
////            }
////        });
//
//        btn.setOnClickListener(new View.OnClickListener() {
//
//
//            @Override
//            public void onClick(View view) {
//
//                password.setText(generateString(10));
//                {
//
//
//
//                }
//            }
//        });
//    }
//
//
//
//    private String generateString(int length) {
//        char[] chars = "QWERTYUIOPASDFGHJKLZXCVBNM0123456789qwertyuiopasdfghjklzxcvbnm!_".toCharArray();
//        Random r = new Random();
//        StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < length; i++) {
//            char c = chars[r.nextInt(chars.length)];
//            StringBuilder append = sb.append(c);
//        }
//        return sb.toString();
//    }
//}
